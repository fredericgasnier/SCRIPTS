package com.formation.ex4;

public class Test4 {

	public static void main(String[] args) {
		int[] tab1 = {1, 2, 3, 4, 5, 6, 7, 8, 9};

//		System.out.println(tab1[0]);
//		
//		for (int i = 0; i < tab1.length; i++) {
//			System.out.println(tab1[i]);
//		}
		
		for (int o : tab1) {
			System.out.println(o);
		}
	}

}
