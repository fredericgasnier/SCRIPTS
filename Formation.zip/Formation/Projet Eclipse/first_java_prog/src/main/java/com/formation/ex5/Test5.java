package com.formation.ex5;

public class Test5 {

	public static void main(String[] args) {

		SuperVoiture sv = new SuperVoiture();
		
		sv.start();

	}

}
