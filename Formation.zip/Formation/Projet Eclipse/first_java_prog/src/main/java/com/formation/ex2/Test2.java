package com.formation.ex2;

public class Test2 {

	public static void main(String[] args) {
		
		//Construction de la voiture
		Voiture Voiture1 = new Voiture();
		
		System.out.println("Puissance : " + Voiture1.power + "\nCouleur de la voiture : " 
		+ Voiture1.color);
		
		Voiture1.color = "Blue";
		
		System.out.println("Couleur de la voiture after : " + Voiture1.color);

		Voiture Voiture2 = new Voiture();
		
		System.out.println("Couleur de la voiture 2 : " + Voiture2.color);
		
	}

}
