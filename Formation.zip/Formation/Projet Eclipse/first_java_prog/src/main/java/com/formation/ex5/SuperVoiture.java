package com.formation.ex5;

import com.formation.ex2.Voiture;

public class SuperVoiture extends Voiture {

	
}
