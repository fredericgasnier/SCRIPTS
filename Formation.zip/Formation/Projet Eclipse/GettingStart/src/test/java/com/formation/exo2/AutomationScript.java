package com.formation.exo2;

import org.openqa.selenium.chrome.ChromeDriver;

public class AutomationScript {

	public static void main(String[] args) { 
		//A utiliser avec Thread.sleep
		//throws InterruptedException {

		String ChromeDriverPath = "C:\\tmp\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", ChromeDriverPath);
		ChromeDriver chrome = new ChromeDriver();
		chrome.manage().window().maximize();
		//Chargement de la page Google
		chrome.get("https://www.google.com");
		
		if (chrome.getTitle().equalsIgnoreCase("google")) {
			System.out.println("Je suis bien chez Google");
		} else {
            System.out.println("KO GOOGLE");
		}
		
//		Thread.sleep(2000);
		
		chrome.navigate().to("http://www.bing.com");
		if (chrome.getTitle().equalsIgnoreCase("bing")) {
			System.out.println("Je suis bien chez bing");
		} else {
            System.out.println("KO BING");
		}
//		Thread.sleep(2000);
		
		//Retour en arri�re
		chrome.navigate().back();
		if (chrome.getTitle().equalsIgnoreCase("google")) {
			System.out.println("Je suis bien chez Google");
		} else {
            System.out.println("KO GOOGLE");
		}
//		Thread.sleep(2000);
		
		//Fl�che Avancer
		chrome.navigate().forward();
		if (chrome.getTitle().equalsIgnoreCase("bing")) {
			System.out.println("Je suis bien chez bing");
		} else {
            System.out.println("KO BING");
		}
//		Thread.sleep(2000);
	
		System.out.println(chrome.manage().window().getSize());
		
		chrome.quit();
	}

}
