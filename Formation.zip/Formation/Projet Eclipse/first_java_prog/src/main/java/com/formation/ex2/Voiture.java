package com.formation.ex2;

public class Voiture {

	String color = "red";
	int power = 12;
	public String marque = "BMW";
	private String carburant = "Essence";

//A cr�er d�s qu'un constructeur existe

	public Voiture() {
	}

	/**
	 * Sans utilistaion de this, utilisation de varialbles en plus
	 * 
	 * public Voiture(String colora, int powera, String marquea) {
	 * 
	 * color = colora; power = powera; marque = marquea; }
	 **/

	public Voiture(String color, int power, String marque) {

		this.color = color;
		this.power = power;
		this.marque = marque;
	}

	public void start() {
		System.out.println("Car starting .........");
	}

	public void stop() {
		System.out.println("Car stopped !!!!!!!!!");
	}

	public int vitesse(int a) {

		if (a <= 0 || a >= 5) {
			return a;
		}
		if (a == 1)
			return a * power * 2;
		if (a == 2) {
			return a * power * 3;
		}
		if (a == 3) {
			return a * power * 4;
		} else {
			return a * power * 5;
		}
	}

}
