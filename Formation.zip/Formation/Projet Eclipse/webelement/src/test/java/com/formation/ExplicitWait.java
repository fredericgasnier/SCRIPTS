package com.formation;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

//Attente sur une partie de la page
public class ExplicitWait {

	public static void main(String[] args) {
	String ChromeDriverPath = "C:\\tmp\\chromedriver.exe";
	System.setProperty("webdriver.chrome.driver", ChromeDriverPath);
//	public static void main(String[] args) {
//		ImplicitWaitTest();
//	}
	WebDriver driver = new ChromeDriver();
//	private static void ImplicitWaitTest {
		Path sampleFile = Paths.get("pages/activity_5_B-1.html");
		driver.get(sampleFile.toUri().toString());
		
		try {
			driver.findElement(By.id("runTestButton")).click();
			
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.titleContains("Explicit"));
			
			if (driver.getTitle().startsWith("Explicit")) {
				System.out.println("Explici worked, element contains Explicit");
			} else {
				System.out.println("Explicit was not found");
			}
		} finally {
			
			driver.quit();
		}
		
		
//	}
	
	}
	
}
