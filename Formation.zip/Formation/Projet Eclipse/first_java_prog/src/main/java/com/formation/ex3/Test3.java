package com.formation.ex3;

import com.formation.ex2.Voiture;

public class Test3 {

	public static void main(String[] args) {
		
		Voiture v1 = new Voiture();
		Voiture v2 = new Voiture("Yellow", 15, "Renault");
		
		System.out.println("Marque : " + v2.marque);
		System.out.println("Marque : " + v1.marque);
		
		v1.start();
		v1.stop();
		System.out.println(v1.vitesse(0));
		System.out.println(v1.vitesse(1));
		System.out.println(v1.vitesse(2));
		System.out.println(v1.vitesse(3));
		System.out.println(v1.vitesse(4));
		System.out.println(v1.vitesse(5));
	}

}
