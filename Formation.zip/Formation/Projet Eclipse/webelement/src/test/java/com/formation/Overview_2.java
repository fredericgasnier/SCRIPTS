package com.formation;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Overview_2 {

	public static void main(String[] args) throws InterruptedException {

		String ChromeDriverPath = "C:\\tmp\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", ChromeDriverPath);

		WebDriver driver = new ChromeDriver();

		Path sampleFile = Paths.get("pages/activity-2.html");
		driver.get(sampleFile.toUri().toString());
		// Thread.sleep(2000);
		// try-catch rentre dans le catch si erreur
		// try-finally rentre dans le finally erreur ou non qui ferme les connexions
		try {

			WebElement lastname = driver.findElement(By.id("lastName"));

			if (lastname.isDisplayed()) {
				lastname.sendKeys("Fred");
				System.out.println("lastName visible");
				System.out.println(lastname.getAttribute("value"));
			} else {
				System.out.println("LastName non visible");
			}

			WebElement hobbies = driver.findElement(By.name("hobbies"));
			if (hobbies.isDisplayed()) {
				System.out.println("Hobbies visible");
			} else {
				System.out.println("Hobbies non visible");
			}

			WebElement firstname = driver.findElement(By.className("form-control"));
			if (firstname.isDisplayed()) {
				System.out.println("firstname visible");
			} else {
				System.out.println("Firstname non visible");
			}

			List<WebElement> div = driver.findElements(By.tagName("div"));

			if (div.size() > 0) {
				System.out.println("Plus de zeros div");
			} else {
				System.out.println("Aucun div");
			}

			WebElement spanishLink = driver.findElement(By.linkText("Spanish"));
			String link = spanishLink.getAttribute("href");
			if (!"".equals(link)) {
				System.out.println("le lien est trouve : " + link);
			} else {
				System.out.println("Pas de lien trouv�");
			}

			WebElement textArea = driver.findElement(By.id("aboutYourself"));

			if (textArea.isEnabled() && textArea.isDisplayed()) {
				System.out.println("Visible et display");
//				Thread.sleep(2000);
				if ("".equals((textArea.getAttribute("value")))) {
					System.out.println("area vide");
				} else {
					System.out.println("area rempli");
				}
//				Thread.sleep(2000);
				textArea.sendKeys("simple texte");
//				Thread.sleep(2000);
				if ("simple texte".equalsIgnoreCase(textArea.getAttribute("value"))) {
					System.out.println("text correct in arrea");
				} else {
					System.out.println("something went wrong");
				}
//				Thread.sleep(2000);
				textArea.clear();
//				Thread.sleep(2000);
				if ("".equals(textArea.getAttribute("value"))) {
					System.out.println("area is empty after clean");
				} else {
					System.out.println("area not clean");
				}

				//Thread.sleep(2000);

			} else {
				System.out.println("area is not visible and not displayed");
			}
			
			Select singleChoiceList = new Select(driver.findElement(By.id("monthOfBirth")));
			
			if (!singleChoiceList.isMultiple() && singleChoiceList.getOptions().size() == 13) {
				System.out.println("list not accept multiple choice and contain 13 elements");
				Thread.sleep(2000);
				singleChoiceList.selectByVisibleText("April");
				if (singleChoiceList.getFirstSelectedOption().getText().equalsIgnoreCase("February")) {
					System.out.println("it work, feb is select");
				} else {
					System.out.println("Attention, Feb not selected");
				}
			} else {
				System.out.println("something went wrong");
			}
			
			JOptionPane.showMessageDialog(null,"Hello");
			JOptionPane.showMessageDialog(null, "fred", "Interrogation", 3);
			//JOptionPane.showInputDialog("Hello");
			
			Select multipleChoiceList = new Select(driver.findElement(By.id("hobbies")));
			
			if (multipleChoiceList.isMultiple() && multipleChoiceList.getOptions().size() == 4) {
				System.out.println("list accept choix multiple et contient 4 options");
				multipleChoiceList.selectByVisibleText("Reading");
				multipleChoiceList.selectByVisibleText("Sports");
				multipleChoiceList.selectByVisibleText("Traveling");
//				Thread.sleep(2000);
				multipleChoiceList.deselectByVisibleText("Sports");
//				Thread.sleep(2000);
				if (multipleChoiceList.getAllSelectedOptions().size() == 2) {
					System.out.println("Selection de 2 cases");
				} else {
					System.out.println("La s�lection est fausse");
				}
				
				List<String> expectedSelection = Arrays.asList("Reading", "Traveling");
				List<String> actualSelection = new ArrayList<String>();
				
				for (WebElement element : multipleChoiceList.getAllSelectedOptions()) {
					actualSelection.add(element.getText());
				}
				
				if (actualSelection.containsAll(expectedSelection)) {
					System.out.println("it worked, ils sont s�lectionn�");
				} else {
					System.out.println("S�lection HS");
				}
								
 			} else {
 				System.out.println("not multiple");
			}
			
			
			
			
//			Thread.sleep(2000);
			WebElement masters = driver.findElement(By.cssSelector("input[value='masters']"));
//			Thread.sleep(2000);
			if (masters.isEnabled() && masters.isDisplayed()) {
				System.out.println("radio buton is enable and visible");
				if (!masters.isSelected()) {
//					Thread.sleep(2000);
					masters.click();
//					Thread.sleep(2000);
					if (masters.isSelected()) {
						System.out.println("Masters a �t� selectionn�");
					} else {
						System.out.println("Wrong, not selected");
					}
				}
			} else {
				System.out.println("Not enable and not visible");
			}
			
			
			WebElement emailUpdate = driver.findElement(By.id("emailUpdates"));
			
			
			
			
			if (emailUpdate.isEnabled() && emailUpdate.isDisplayed()) {
				System.out.println("Checkbox visible et enable");
				if (!emailUpdate.isSelected()) {
//					Thread.sleep(2000);
					emailUpdate.click();
//					Thread.sleep(2000);
					if (emailUpdate.isSelected()) {
						System.out.println("email vient detre s�lected");
					} else {
						System.out.println("Ca n'a pas march�");
					}
				}
				
			} else {
				System.out.println("not enable and not visible");
			}
			
			
			
			
		} finally {
			driver.close();
		}
	}

}