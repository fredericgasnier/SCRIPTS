package com.formation.ex6;

public class Test6 {

	public static void main(String[] args) {
		String mot = "kayak";
		StringBuffer sb = new StringBuffer(mot).reverse();

	//	sb.reverse();

		String reverse = sb.toString();

		// Java le fait auto
		System.out.println(sb.toString());

		if (mot.contentEquals(reverse)) {
			System.out.println("C'est pal");
		} else {
			System.out.println("ce n'est pas un pal");
		}

	}

}
