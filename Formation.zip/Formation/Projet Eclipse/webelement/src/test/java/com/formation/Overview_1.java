package com.formation;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Overview_1 {

	public static void main(String[] args) throws InterruptedException {

		String ChromeDriverPath = "C:\\tmp\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", ChromeDriverPath);

		WebDriver driver = new ChromeDriver();

		// try-catch rentre dans le catch si erreur
		// try-finally rentre dans le finally erreur ou non qui ferme les connexions
		try {
			Path sampleFile = Paths.get("pages/activity-1.html");
			driver.get(sampleFile.toUri().toString());
			Thread.sleep(2000);
			WebElement spanish = driver.findElement(By.id("spanish"));
			spanish.click();
			Thread.sleep(2000);

			WebElement email = driver.findElement(By.id("inputEmail"));

			email.sendKeys("email@gmail.com");
			Thread.sleep(2000);
			if (email.getAttribute("value").equalsIgnoreCase("email@gmail.com")) {
				System.out.println("Le script a fonctionn� email@gmail.com a �t� tap�");
			} else {
				System.out.println("Script KO");
			}
			

		} finally {
			driver.close();
		}
	}

}
