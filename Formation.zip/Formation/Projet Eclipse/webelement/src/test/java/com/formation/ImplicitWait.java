package com.formation;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.ExpectedCondition;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;

//Attente au niveau de la page globale
public class ImplicitWait {

	public static void main(String[] args) {
		
		String ChromeDriverPath = "C:\\tmp\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", ChromeDriverPath);

		WebDriver driver = new ChromeDriver();

		Path sampleFile = Paths.get("pages/activity_5_A-1.html");
		driver.get(sampleFile.toUri().toString());

		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
		try {
			driver.findElement(By.id("runTestButton")).click();;
			
			WebElement info = driver.findElement(By.id("lesson"));
			if (info.getText().contains("run")) {
				System.out.println("Implicit worked, element contains run");
			} else {
				System.out.println("Implicit KO, run was not found");
			}
			
			
		} finally {
			// : handle finally clause
			driver.close();
		}
		
		
	}
}
