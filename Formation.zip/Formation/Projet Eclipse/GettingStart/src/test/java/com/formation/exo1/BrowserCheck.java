package com.formation.exo1;

import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCheck {

	public static void main(String[] args) throws InterruptedException {

		String ChromeDriverPath = "C:\\tmp\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", ChromeDriverPath);

		//ouvrir un navigateur Chrome
		
		ChromeDriver WebDriver = new ChromeDriver();
		
		Thread.sleep(5000);
				
		
		WebDriver.quit();
	}

}
